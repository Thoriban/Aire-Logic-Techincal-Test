﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aire_Logic_Technical_Test
{
    public class Song
    {
        public string artist { get; set; }
        public string title { get; set; }
        public string lyrics { get; set; }
    }
}
